//  GitHub: https://github.com/Tate-zwt/WTSDK
//  TestViewController.h
//  WTSDK
//
//  Created by 张威庭 on 16/9/8.
//  Copyright © 2016年 zwt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestViewController : UIViewController

@end
