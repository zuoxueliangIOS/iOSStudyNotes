//  GitHub: https://github.com/Tate-zwt/WTSDK
//  ViewController.h
//  WTSDK
//
//  Created by 张威庭 on 15/12/16.
//  Copyright © 2015年 zwt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
